/**
 * Created by khiempnk on 5/15/18.
 */

api = {
    loadMoreProduct: "http://pcshop.test/index/getProducts",
    addCart: "http://pcshop.test/carts/addCart"
};

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

product = {};
product = {
    template: function () {
        return $("#template_product").html()
    },
    currentPage: 0,
    loading : {
        loadMore:{
            open:function () {
                $("#btn_load_more").prop('disabled', true);
            },
            close(){
                $("#btn_load_more").prop('disabled', false);
            }
        }
    },
    view:{
        addProducts: function (html) {
            $("#products").append(html);
        },
        displayProducts: function (products) {
            if (products.length == 0){
                this.displayNoProducts("No more product");
            }else {
                var i;
                for (i = 0; i < products.length; i++) {
                    p = products[i];
                    var template = product.template();
                    template = template.replaceAll("{{name}}", p.name)
                        .replaceAll("{{price}}", p.price);
                    this.addProducts(template);
                }
            }
        },
        displayNoProducts: function (message) {
            alert(message);
        },
        displayError: function (message) {
            console.log(message);
        }
    },
    service: {
        nextPage:function () {
            product.currentPage  = product.currentPage + 1;
            return product.currentPage ;
        },
        loadMore: function () {
            product.loading.loadMore.open();
            $.ajax({
                method: "POST",
                url: api.loadMoreProduct,
                data: {page: this.nextPage()}
            }).success(function (products) {
                console.log(products);
                product.view.displayProducts(JSON.parse(products));
                product.loading.loadMore.close();
            }).error(function (message) {
                product.view.displayError(message);
                product.loading.loadMore.close();
            });
        }
    }
};

cart = {};
cart = {
    view:{
        displayNumberCart: function (numberCart) {
            var countCart = $("#countCart");
            countCart.html(parseInt(countCart.text()) + numberCart);
        },
        displayError: function (message) {
            console.log(message);
        }
    },
    service:
    {
        addCart: function (product_id) {
            $.ajax({
                method: "POST",
                url: api.addCart,
                data: {product_id : product_id}
            }).success(function (jsonResult) {
                console.log(jsonResult);
                cart.view.displayNumberCart(1);
            }).error(function (message) {
                cart.view.displayError(message);
            });
        }
    }
};



