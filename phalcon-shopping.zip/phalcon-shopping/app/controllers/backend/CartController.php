<?php

class CartController extends \Phalcon\Mvc\Controller
{

    public function indexAction()
    {

    }

}

