<?php

namespace Application\Controllers\Backend;

class IndexController extends ControllerBase
{
    public function indexAction()
    {
//        $this->assets->addCss('html-master/vendor/bootstrap/css/bootstrap.css');
        $this->styleJs();
    }

    public function styleJs()
    {
        $this->assets->addCss('html-master/vendor/bootstrap/css/bootstrap.css');
        $this->assets->addCss('html-master/vendor/bootstrap/css/font-awesome.min.css');
        $this->assets->addCss('html-master/css/style.blue.css');
        $this->assets->addCss('html-master/css/custom.css');
        $this->assets->addJs("html-master/vendor/bootstrap/js/bootstrap.min.js");
        $this->assets->addJs("html-master/vendor/jquery.cookie/jquery.cookie.js");
        $this->assets->addJs("html-master/vendor/chart.js/Chart.min.js");
        $this->assets->addJs("html-master/vendor/js/charts-home.js");
        $this->assets->addJs("html-master/js/front.js");
    }

}

