<?php
namespace Application\Controllers\Backend;
use Application\Models\Brands;
class BrandsController extends ControllerBase
{

    /**
     * The start action, it shows the "search" view
     */
    public function indexAction()
    {
        $this->styleJs();
        $this->view->brands = Brands::find();
    }

    /**
     * Execute the "search" based on the criteria sent from the "index"
     * Returning a paginator for the results
     */
    public function searchAction()
    {
        // ...
    }

    /**
     * Shows the view to create a "new" product
     */
    public function newAction()
    {
        $this->styleJs();
//        $this->view->brands = Brands::find();
    }

    /**
     * Shows the view to "edit" an existing product
     */
    public function editAction($id)
    {
        $this->styleJs();
        $this->view->brand = Brands::findFirst($id);
    }

    /**
     * Creates a product based on the data entered in the "new" action
     */
    public function createAction()
    {
        $user = new Brands();

        // Store and check for errors
        $success = $user->save(
            $this->request->getPost(),
            [
                "name"
            ]
        );

        if ($success) {

            // Using direct flash
            $this->flash->success("Bạn đã thêm thành công ");

        } else {
            $messages = $user->getMessages();

            foreach ($messages as $message) {
                $this->flash->error( $message->getMessage());
            }
        }

        // Forward to the index action
        return $this->dispatcher->forward(
            [
                "action" => "index"
            ]
        );
    }

    /**
     * Updates a product based on the data entered in the "edit" action
     */
    public function saveAction($id)
    {
        $this->styleJs();
        $brand = Brands::findFirst($id);

        // Store and check for errors
        $success = $brand->save(
            $this->request->getPost(),
            [
                "name"
            ]
        );

        if ($success) {

            // Using direct flash
            $this->flash->success("Bạn đã sửa thành công ");
            // Forward to the index action
            return $this->dispatcher->forward(
                [
                    "action" => "index"
                ]
            );

        } else {
            $messages = $brand->getMessages();

            foreach ($messages as $message) {
                $this->flash->error( $message->getMessage());
            }
        }


    }

    /**
     * Deletes an existing product
     */
    public function deleteAction($id)
    {
        $this->styleJs();
        $brand = Brands::findFirst($id);

        $success = $brand->delete();

        if ($success) {

            // Using direct flash
            $this->flash->success("Bạn đã xóa thành công ");
            return $this->dispatcher->forward(
                [
                    "action" => "index"
                ]
            );

        } else {
            $messages = $brand->getMessages();

            foreach ($messages as $message) {
                $this->flash->error( $message->getMessage());
            }
        }
    }

    public function styleJs()
    {
        $this->assets->addCss('html-master/vendor/bootstrap/css/bootstrap.css');
        $this->assets->addCss('html-master/vendor/bootstrap/css/font-awesome.min.css');
        $this->assets->addCss('html-master/css/style.blue.css');
        $this->assets->addCss('html-master/css/custom.css');
        $this->assets->addJs("html-master/vendor/bootstrap/js/bootstrap.min.js");
        $this->assets->addJs("html-master/vendor/jquery.cookie/jquery.cookie.js");
        $this->assets->addJs("html-master/vendor/chart.js/Chart.min.js");
        $this->assets->addJs("html-master/vendor/js/charts-home.js");
        $this->assets->addJs("html-master/js/front.js");
    }

}

