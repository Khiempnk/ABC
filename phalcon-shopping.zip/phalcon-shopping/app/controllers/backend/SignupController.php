<?php

namespace Application\Controllers\Backend;
use Application\Models\Users;

class SignupController extends ControllerBase
{
    public function indexAction()
    {
        $this->styleJs();
    }

    public function registerAction()
    {
        $user = new Users();
        $user->name =  $this->request->getPost('name');
        $user->email =  $this->request->getPost('email');
        $user->password =  md5(12345678);
        $user->save();


        if ($user) {
            echo "Thanks for registering!";
        } else {
            echo "Sorry, the following problems were generated: ";

            $messages = $user->getMessages();

            foreach ($messages as $message) {
                echo $message->getMessage(), "<br/>";
            }
        }

        $this->view->disable();
    }

    public function styleJs()
    {
        $this->assets->addCss('html-master/vendor/bootstrap/css/bootstrap.css');
        $this->assets->addCss('html-master/vendor/bootstrap/css/font-awesome.min.css');
        $this->assets->addCss('html-master/css/style.default.css');
        $this->assets->addCss('html-master/css/custom.css');
        $this->assets->addJs("html-master/vendor/bootstrap/js/bootstrap.min.js");
        $this->assets->addJs("html-master/vendor/jquery.cookie/jquery.cookie.js");
        $this->assets->addJs("html-master/vendor/chart.js/Chart.min.js");
        $this->assets->addJs("html-master/vendor/js/charts-home.js");
        $this->assets->addJs("html-master/js/front.js");
    }
}