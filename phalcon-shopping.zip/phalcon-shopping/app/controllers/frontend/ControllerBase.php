<?php

namespace Application\Controllers\Frontend;
use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{

    public function initialize()
    {
        // Default title
        $this->tag->setTitle("Frontend");
        $this->getJs();
        $this->getCss();
    }

    public function afterExecuteRoute()
    {
        $this->view->setViewsDir($this->view->getVIewsDir() . 'frontend/');
    }
    private function getCss(){
        $root_css = "eshopper";
        $css_links =  [
            "css/bootstrap.min.css",
            "css/font-awesome.min.css",
            "css/prettyPhoto.css",
            "css/price-range.css",
            "css/animate.css",
            "css/main.css",
            "css/style.css"
        ];

        foreach ($css_links as $css_link){
            $this->assets->addCss($root_css.'/'.$css_link);
        }
    }

    private function getJs(){
        $root_js = "eshopper";
        $js_links = [
            'js/jquery.js',
            'js/bootstrap.min.js',
            'js/jquery.scrollUp.min.js',
            'js/price-range.js',
            'js/jquery.prettyPhoto.js',
            'js/main.js',
            'js/page/index.js'
        ];
        foreach ($js_links as $js_link){
            $this->assets->addJs($root_js.'/'.$js_link);
        }
    }

    public function showDie($value){
        die(var_dump($value));
    }
    public function backHome(){
        return 1;
    }
}