<?php

namespace Application\Controllers\Frontend;
use Application\Models\Categories;

class CategoriesController extends ControllerBase
{

    public function indexAction()
    {
        if(isset($_GET['id'])) {
            $this->view->categories = $this->getCategories();
            $this->view->brands = $this->getBrands();
            $this->view->products = $this->getProducts(0, $_GET["id"]);
            $this->view->category_detail = $this->getCategory($_GET["id"]);
        }
    }

    private function getCategory($id){
        return Categories::findFirst($id);
    }

    private function getBrands(){
        $brand = $this->modelsManager->createBuilder()
            ->from(['Brands'=>'m:Brands'])
            ->leftJoin("m:Product",'Brands.id = Product.brand_id',"Product")
            ->columns(['Brands.id', 'Brands.name', 'COUNT(Product.id) as total_product'])
            ->groupBy("Brands.id")
            ->limit(25)
            ->getQuery()
            ->execute();
        return $brand;
    }

    private function getCategories($limit=25){
        $categories = Categories::find(["limit"=>$limit]);
        return $categories;
    }

    private function getProducts($page, $category_id, $limit=30){

         $product =   $this->modelsManager->createBuilder()
            ->from(["Product" => "m:Product"])
             ->where("category_id = ".$category_id)
             ->limit( ($page * $limit), $limit)
            ->getQuery() ->execute();

        return $product;
    }

    /***
     * Load more products
     * @return string
     */
    public function getProductsAction(){
        return json_encode($this->getProducts($this->request->getPost()["page"], 1));
    }


}